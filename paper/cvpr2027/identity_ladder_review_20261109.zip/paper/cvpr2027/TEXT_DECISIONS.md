# Text decision log

This append-only log records manuscript decisions, their evidence and checks. A working verdict is not a substitute for source results. Dates refer to manuscript assembly on 8 November 2026.

## Iteration 00: establish the authoritative source

**Inputs:** workstation handoff; cvpr2027-paper at a48523d; the older non-Git Syncthing copy.

**Finding:** the branch contains a manuscript skeleton, while the earlier local draft used a narrower and older evidence set. The Git branch and its protocols are the assembly authority.

**Decision:** clone the fork outside Syncthing, retain the branch, preserve the ISBI source, and write only the paper plus the explicitly requested figure-generator import. Do not overwrite the branch with the old monolithic draft.

**Checks:** verified branch, remote and commit; read AGENTS.md and the reproduction workflow. No push was performed.

## Iteration 01: distinguish current, provisional and absent evidence

**Inputs:** general donor protocol; brain amendments through 21; fundus amendments; face and iris handoffs; saved result JSONs.

**Finding:** brain registration remains pre-QC, current accessible fundus tables are P7, face tier-1 has an approved v6f frame but lacks its base pipeline/protocol, and the latest full iris P3 is absent from Git.

**Decision:** label source-dependent provisional results P, distinguish unavailable from not run and undefined, exclude superseded support-sensitive block searches, and retain newer-protocol specifications without claiming their sweeps finished.

**Scientific consequence:** the text can describe metric profiles but cannot infer a validated biological identity ordering. Historical low-level ocular pilots are not primary evidence for the newer iris strip panel.

**Checks:** read endpoint counts and scale definitions directly from aggregate files; generated source hashes and producing commits. No experiments were rerun.

## Iteration 02: make claims match their measurement scope

**Inputs:** QTIM tier-1 R profiles, face v6f pixel and ArcFace reference profiles, P2 iris profiles and directional tests.

**Finding:** repeat-anchored and self-anchored values differ in their zero. The face ArcFace reference is whole-image donor identity, whereas the pixel distance is local. A failure of T2 does not prove equivalence.

**Decision:** retain both anchors by name, state the spatial-scope mismatch explicitly, and report the attenuation confidence intervals separately from the one-sided test decision. Do not call a context donor an identity-preserving inpainting.

**Change:** replaced section TODOs with methods, measured-results prose, limitations and a distinct LLM statement. Added source-generated coverage, brain, face and iris tables.

**Checks:** preparation reads aggregate files only. Initial full pytest: 344 passed, 8 skipped, 6 failures caused by missing optional dependencies and incompatible environment versions. These failures were preserved and are not reported as passes; environment alignment is in progress.

## Iteration 03: author decisions and the first-draft boundary

**Inputs:** author replies to the three handoff questions and the requested iteration/skill workflow.

**Decisions:** assemble now from the available Git snapshot; prepare the main figure with Gaussian brain and provisional fundus; Codex will integrate face files after they arrive. Apply scientific-writing, scientific-critical-thinking, conference-submission-audit, repro-judge and academic-discoverability, with decisions logged on every iteration.

**Figure consequence:** the private-data map pipeline cannot run on this host. Use immutable published aggregate PDF panels, replace the obsolete brain row with the existing Gaussian panel, regenerate annotations from its JSON, and record that this is PDF-panel assembly rather than a new map computation. Preserve the complete source-derived atlas in the supplement and identify P2 iris as P2.

**Next checks:** assess figure scales and privacy; inventory all available materials; perform claim-level reproduction and scientific reviews; complete the metadata editorial pass; render and audit the final first-draft PDFs.

## Iteration 04: recover the available bilateral evidence

**Inputs:** immutable bilateral commit 82ed7fe, its P8/P9 frame-only and completed v1 fundus metric JSONs, saved atlas PDF and generator; current Gaussian brain maps.

**Finding:** the available Git history contains newer fundus aggregates than the initial CVPR checkout. P7 is therefore no longer the strongest accessible frame-only source. The still newer running extension is a different source.

**Decision and change:** preserve the exact bilateral JSON blobs in paper inputs, generate the primary fundus table and coverage from P8/P9, retain P7 as history, and add the v1-versus-P2 metric availability registry. Assemble the requested atlas now from immutable aggregate PDF panels, replace the stale brain row with Gaussian panels, and retain secondary iris rows in the supplement. Scalar brain annotations are pooled, not slice-only estimates.

**Checks:** source hashes and producing commits are recorded; common diverging ratio scales were checked against the source generators. Fixed an imported PDF footer-font resource issue detected by pdftotext. No map arrays were recomputed and no participant exemplar was introduced. New generator code has a source hash because it has not yet been committed.

## Iteration 05: material coverage and claim-level review

**Inputs:** 263 tracked scientific artifacts across 14 material families; CARE iteration-2 rows; the existing repro-judge icml2026_v2 rubric; current manuscript and numerical source records.

**Finding:** historical simulations, unregistered pilots, fixed real-case demonstrations and CARE score reaggregation answer different questions from the main anatomical donor panels. Author PASS/F/P labels do not by themselves establish reproduction.

**Decision and change:** map every inventoried material to a text role or exclusion reason. Include the narrow CARE audit and historical correlation/size sensitivity in the supplement; keep synthetic evidence as mechanism controls. The Codex documentary claim review assigns five verified, two toy and one inconclusive verdicts (12/16 under the unchanged rubric), with no probability or independent-rerun interpretation. Preserve the P3 H4 failure report as pending numerical integration rather than inventing a figure.

**Checks:** distinguished person versus eye, local pixels versus whole-image ArcFace, repeat versus self anchors, and failure of a directional test versus equivalence. Added explicit intensity definitions for TM-like and lDDT-like adaptations with verified original-method references. Scientific and reproduction review files retain the remaining confounders and provenance limits.

## Iteration 06: title, abstract and citation fidelity

**Inputs:** academic-discoverability skill, evidence ledger, ten generated query intents and three near misses; Crossref/arXiv and official primary proceedings; bib-verify output.

**Decision and change:** apply “Identity Ladder: Auditing Image Similarity for Individual Anatomy” to main and supplement. The abstract states the four domains, controls and two measured comparisons, retaining their different anchors/scopes and provisional boundaries. No universal identity metric or trained-model benchmark is claimed. Keep the generated query panel as an editorial check, not a measured retrieval gain.

**Checks:** the title is eight words and the abstract 214 words. All bibliography entries go through bib-verify. Retain correct published conference years for Betti matching and FWD despite automatic preprint-year flags; document primary-source resolutions and the surname-diacritic false flag without rewriting the automatic report. Corrected the escaped DOI, print year and rendered accent issues in the metadata generator.

## Iteration 07: build, tests and venue-file review

**Inputs:** official current CVPR 2027 author guide; official author-kit Git tag CVPR2027-v1; compiled main and supplement; full repository tests.

**Finding:** the initial main reading copy uses eight content pages, with LLM statement before references on the next page. The supplementary initially had a blank title-only page and an overfull float page. The direct kit ZIP download timed out, while the primary official Git tag was reachable and matched the local style byte-for-byte.

**Decision and change:** remove the blank supplementary cover break, separate and bound the historical figure pages, scan identifying text and unresolved references, and visually inspect rendered pages. Treat compliance of inspected files separately from unknown portal, overlap and ethics facts. Keep paper build requirements and commands distinct from experimental reproduction.

**Code verification:** full pytest completed with 349 passed, 8 skipped, 1 failed. The remaining real-cases guard correctly refuses Python 3.12 where its frozen protocol requires 3.11. Do not relax another owner's guard or report an all-pass suite. Tests downloaded a model into an accidental Windows-style relative cache directory under WSL; remove this session-generated cache from the working tree after the run.

**Remaining boundary:** first-draft delivery does not wait for unavailable private exports, as authorized. Final submission and push still require the author's PDF review and resolution of the separately listed source/QC/administrative facts. Final PDF hashes, layout checks and page counts are recorded in verification.json after the corrected build.

## Iteration 08: read the figure at manuscript size

**Finding:** the first eight-column atlas was valid as an aggregate assembly but its scaled annotation text was too small on the main-paper page. The PDF-panel API also exposes off-clip images inside nested forms, so image-bound extraction alone can crop a replacement panel incorrectly.

**Decision and change:** retain six key columns and all six primary-domain/dataset rows in the main figure, redraw labels and the scale at native manuscript size, and keep all eight columns/eight rows in the supplement. Use original source panel bounds for original rows and explicit replacement bounds for brain. Retain the exact displayed source annotations, with a fit assertion for every new text box. No source map or measured value is recalculated.

**Scientific clarification:** the main caption now distinguishes pooled mean-error map summaries and 16-donor context means from anchored, window-level, often single-donor metric tables. The last column is labeled mean-fill V rather than implying a separately established biological variance. Brain remains Gaussian/provisional, fundus P8/P9 provisional, and the iris panel P2 rather than P3.

**Checks:** visually inspected the enlarged atlas and the complete main/supplement contact sheet; inspected main numerical-table pages at reading resolution. Corrected missing text-box fits and the brain crop before accepting the new figure. A final rebuild updates the exact PDF hashes and file audit.

## Iteration 09: accept the reviewable first draft

**Final artifacts:** main PDF is nine pages total: eight content pages and one page for the LLM statement/references. The separate supplement is eleven pages. No section TODO remains. Tables and figures have source/generator hashes and producing-commit records. The final generated report records no overfull boxes, missing glyphs, unresolved references or identifying-text hits in either PDF. Rendered-page inspection confirms legible main-atlas labels and no blank cover, clipped captions or overflowing supplementary figures.

**Verification limits retained:** the TeX build still emits upstream lineno UTF-8 and included-PDF-version warnings, without observed missing text or rendering defects. The full test result remains 349 passed, 8 skipped and one Python-version guard failure. Seventeen of twenty bibliography entries have unflagged automatic verification; three primary-source manual resolutions are documented, with the automatic flags preserved. These are distinct checks and none establishes independent experimental reproduction.

**Delivery decision:** the available-snapshot first-draft objective is complete. Continue later with full P3 aggregate integration, receipt of the face base files, experiment QC and author-specific submission facts. The paper is local, uncommitted and unpushed. The legacy private-data generator is explicitly labeled historical; the current paper entry point is build.py and its Gaussian PDF-panel assembler. The generated metric board was refreshed and left outside the intended paper change set.

## Iteration 10: hand off independent paper and result review (9 November 2026)

**Request:** prepare a handoff for reviewing the manuscript and its scientific results.

**Checks:** re-read the current Git state, stored PDF verification, scientific/reproduction audits and full-test summary. The branch is still at a48523d, and the new draft remains local, uncommitted and unpushed. The saved PDF hashes and evidence boundary are unchanged. No experiment, new citation verification or conference-rule audit was performed for this handoff.

**Decision and change:** create HANDOFF_REVIEW.md with exact checkout/base, source-to-claim anchors, review priorities, provenance/scale pitfalls, missing exports, prior-check limits and concrete independent-review outputs. Warn that a GitHub checkout alone does not contain this draft. Provide an author-review overlay ZIP containing current public manuscript materials, reading PDFs and a hashed snapshot manifest, excluding private data, model caches, Git metadata and transient build files. Existing author audits must be challenged rather than inherited as reviewer verdicts.

**Boundary:** the reviewer is asked to inspect and report before rewriting. No experiment, commit, push or message to another agent is requested. The handoff preserves the registration gate, result ownership and the author's earlier decisions to proceed from this Git snapshot, use Gaussian brain panels with provisional fundus, and integrate base face files only after receipt.
