# Scientific review of the first draft

Method: scientific-critical-thinking plus scientific-writing. This is a manuscript-development review, not independent peer review or an experiment rerun.

## Conclusions retained

The current material supports descriptive, source-specific metric profiles. It also supports a design for separating reference distortion, residual amplitude, target alignment and acquisition variation. It does not establish a universal biological ordering, a fused identity score, a new reconstruction method, or a completed cross-domain model benchmark.

## Consequential reasoning checks and text decisions

| Issue | Evidence or alternative explanation | Text decision |
|---|---|---|
| Mean advantage versus identity | Lower expected squared error can follow from variance reduction without target-specific information | Describe metric preference; do not interpret the mean as better preserved personal anatomy |
| Circular reference target | Early reality-B ordering used measured squared error; later axioms remain normative rather than biological ground truth | Retain empirical profiles and explicit assumptions; do not present fit to the axioms as independent identity validation |
| Repeat versus self anchors | A repeat photograph has acquisition and appearance differences; self has exact analytic distance | Name R_repeat and R_self separately and do not combine them into a cross-domain leaderboard |
| Local pixels versus ArcFace | One comparison is a local window; the other is a whole donor image | Report the descriptive disagreement and explicitly exclude an inpainted-composite identity interpretation |
| Failed directional test | Non-significance of repeat superiority does not imply equivalence or significant reverse ordering | State not established for T2 and report the attenuation interval separately |
| Biological and acquisition confounding | Brain registration remains unresolved; bilateral images share capture factors; longitudinal anatomy can change | Keep P status and avoid causal scanner, symmetry or biological claims |
| Missing support and selected donors | Padding can win a search or pull an estimated mean toward a filler | Keep validity masks throughout, exclude superseded block searches, retain eligible counts |
| Pooling and uncertainty | Both eyes, regions and repeated pairs are dependent; ratio of means and mean of ratios differ | Preserve independent people/families, source weights and one-/two-way bootstrap distinctions |
| Gaussian maps and display scale | A smoothing/display convention is not an empirical identity theorem | Preserve masked Gaussian windows and common ratio scale; distinguish V's row-specific scale and scalar annotation scope |
| Topology and distribution distances | Betti matching was developed for segmentations; FID/FWD are set-level; intensity adaptation and support selection can alter interpretation | Keep the adaptation and unit explicit; do not invent individual scores or full P3 outcomes |
| Window geometry | The latest object-relative sweep is specified but not completely evidenced by the older size file | Report the new definition as a protocol and the old sweep as historical sensitivity |
| Synthetic controls | Known-target shrinkage is algebraically constructed; pupil parameters are simulated | Keep toy/mechanism evidence separate from real-anatomy validation |
| Label overlap | Pointwise modal-label optimality does not prove a general Dice optimum | Retain only conditional synthetic observations, with no universal Dice theorem |
| CARE reproduction | Reaggregating released score files differs from rerunning reconstruction and segmentation | Report the narrow consistency audit; do not refute CARE's broader method from mismatched aggregates |
| Publication and ethics | Prior ISBI overlap, dataset consent and institutional basis require author-specific facts | Keep these unresolved in the author audit; do not invent consent, approval or submission eligibility |

## Remaining scientific uncertainties

The first draft cannot remove registration bias, establish the origin of every upstream number, or validate private image QC from public aggregates alone. Face base-pipeline provenance and the full P3 extension remain pending receipt. Population means and withheld donors are useful controls but do not supply the hidden biological truth of an inpainting task. These limitations determine claim strength and are not repaired by successful typesetting, citation verification, or a text-only reproduction judge.
