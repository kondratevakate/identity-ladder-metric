# Identity Ladder CVPR 2027 first draft

This is a reading draft assembled from the available Git snapshots, not a submission-ready claim of completed cross-domain reconstruction experiments. The primary text is `main.tex` / `main.pdf`; the separate supplement is `supplementary.tex` / `supplementary.pdf`. The PDF outputs and build caches are ignored by Git.

Author clarification, 9 November: the paper should advance metric selection for the next BraTS inpainting competition, without needing to announce a final winner. The revised title is **Identity Ladder: Toward Metric Selection for Brain MRI Inpainting**. `BRATS_METRIC_COVERAGE.md` and `decision_coverage.json` decompose the decision into twelve questions, mapping each to existing evidence, scope and missing validation. Saved official-evaluator probes are now in the results and supplement; the former overview of cohorts and profile plot are retained in the supplement. No new metric experiment was run.

The working branch is `cvpr2027-paper`, initially at `a48523dccd2b70dae2615717d62d8725e5183528`, in `C:\Users\Lenovo\source\identity-ladder-cvpr2027`. `origin` is the owner's public fork. No push or upstream PR was made. The related ISBI source is preserved.

## Rebuild in WSL Ubuntu

Run from the repository root with Python 3.12, the packages in `requirements-paper.txt`, Tectonic 0.17 and Poppler's `pdftotext` installed:

```bash
python -m pip install -r paper/cvpr2027/requirements-paper.txt
python paper/cvpr2027/build.py --tectonic /path/to/tectonic --render
```

The preparation stage reads existing aggregate results only. It creates every table, copies source figures, imports two immutable bilateral-branch JSON blobs, and assembles the atlas using the saved Gaussian brain panels. It does not run a metric experiment, inspect participant images, or reconstruct private maps. The bilateral commit `82ed7fe8a52e557854cf4cd2d02eb47d5803d7cb` must be available in the clone; fetch `origin/donor-ladder-bilateral` if necessary.

`src/ladder_maps_all_figure.py` is the imported historical private-data generator, with a provenance notice. It is not called by the paper build; its original footer must not be mistaken for the current Gaussian atlas specification.

`evidence_manifest.json` and `atlas_provenance.json` record source hashes, producing commits, generator hashes and transformations. Font/metadata creation dates can change output PDF bytes across builds; numerical source identity is checked independently. The current atlas uses fundus P8/P9 and iris P2, with the full secondary-iris atlas in the supplement. The full iris P3 and base face pipeline/protocol remain pending receipt.

Bibliography refresh is separate from the offline manuscript preparation: `fetch_bibliography.py` retrieves Crossref metadata and retains the manually checked official-proceedings entries. Every entry was checked using the installed bib-verify script. `citation_report.json` preserves its automatic verdicts and `citation_report.md` resolves three known false flags against primary sources. The build reads this report; it does not silently claim to have rerun an external verifier.

## Review records

`ASSEMBLY_PLAN.md` defines the iteration cycle. `TEXT_DECISIONS.md` is its append-only decision history. `MATERIALS_COVERAGE.md` and `materials_inventory.json` map the existing materials to manuscript roles. `SCIENTIFIC_REVIEW.md`, `REPRODUCTION_AUDIT.md`, `METADATA_REVIEW.md` and `CVPR_AUDIT.md` record separate scientific, reproduction-evidence, title/abstract and venue checks. These are author-facing development records, not automatically part of the anonymous submission.

Full repository tests were run in the WSL environment: **349 passed, 8 skipped, 1 failed**. The single remaining failure is `tests/test_real_cases.py::test_guard_refuses_changed_inputs_and_missing_amendment`: the frozen real-cases guard requires Python 3.11, while this host's test environment is Python 3.12. No experiment guard was relaxed to make the suite green. The build and table/source checks are separate from this historical environment constraint; successful tests would not establish independent experimental reproduction.

Before submission, the author still needs to settle ISBI overlap, dataset-specific consent/ethics and portal eligibility, integrate the missing safe exports, and resolve experiment QC gates. The rendered PDFs must be reviewed by the author before any push. No individual faces, eye images, subject identifiers or restricted UTIRIS images were added to this draft.

The `identity_ladder_review_20261109.zip` handoff archive preserves the earlier first draft. The separate `identity_ladder_review_20261109_brats_framing.zip` contains the later competition-oriented revision; its snapshot manifest identifies exact files. Do not infer which draft is present from the unchanged Git HEAD alone.
